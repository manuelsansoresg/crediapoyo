<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SliderContent extends Model
{
    //
}
