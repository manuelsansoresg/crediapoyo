@extends('adminlte::page')

@section('title', 'Panel Credi Apoyo')

@section('content_header')
    <h1>Panel</h1>
@stop

@section('content')
    <a href="{{ asset('/') }}" target="_blank" class="btn btn-primary">Ir al sitio</a>
@stop