$('input[type="range"]').rangeslider({
    polyfill: false,

    onSlide: function(position, value) {
        $('#valor').html('$'+value);
    },
});
