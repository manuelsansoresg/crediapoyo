<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            Slider
            <small>Contenido</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Slider</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Slider</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <a href="/admin/slider/create" class="btn btn-app pull-right">
                            <i class="fa fa-plus"></i> Nuevo
                        </a>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                    <table id="slider" class="table table-bordered">
                        <thead>
                        <tr>
                            <th style="width: 10px">#Orden</th>
                            <th>Icono</th>
                            <th>Título</th>
                            <th>Contenido</th>
                            <th></th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                                <tr>
                                    <td><?php echo e($slider->order); ?></td>
                                    <td style="width: 200px">
                                        <img class="img-thumbnail col-md-6 " src="<?php echo e(asset('/img').'/icon_slider/'.$slider->icon); ?>" alt="">
                                    </td>
                                    <td> <?php echo e($slider->title); ?> </td>
                                    <td> <?php echo e($slider->content); ?></td>

                                    <td style="width: 120px">

                                        <?php echo e(Form::open(['route' => ['slider.destroy', $slider->id ],'class' => 'form-inline', 'method' => 'DELETE' ])); ?>

                                        <a href="<?php echo e(route('slider.edit', $slider->id)); ?>" class="btn btn-primary"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
                                        <button onclick="return confirm('¿Deseas eliminar el contenido?')" class="btn btn-danger"> <i class="fa fa-trash-o" aria-hidden="true"></i> </button>
                                        <?php echo e(Form::close()); ?>

                                    </td>
                                </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>

                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app_admin.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/adminlte/plugins/datatable/js/responsive.js')); ?>"></script>
    <script>
        $(function () {

            $('#slider').DataTable({
                'paging'      : true,
                'lengthChange': false,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false,
                "scrollX": true
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crediapoyo\resources\views/slider/index.blade.php ENDPATH**/ ?>