<?php $__env->startSection('title', 'Panel Credi Apoyo'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(asset('/')); ?>" target="_blank" class="btn btn-primary">Ir al sitio</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crediapoyo\resources\views/home.blade.php ENDPATH**/ ?>