<?php $__env->startSection('title', 'Blog'); ?>


<?php $__env->startSection('content_header'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('vendor/summernote/summernote.css')); ?>">

    <section class="content-header">
        <h1>
            Slider
            <small>Nuevo</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li><a href="/admin/slider">Slider</a></li>
            <li class="active">Nuevo</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Nuevo slider</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo e(Form::open(['route' => 'slider.store', 'method' => 'POST', 'files' => true])); ?>


                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="exampleInputEmail1">titulo</label>
                            <input type="text" class="form-control" name="titulo">
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('contenido')); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Icono</label>
                            <input type="file" name="icono" class="form-control">
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('icono')); ?></span>
                            <?php endif; ?>
                        </div>




                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Contenido</label>
                            <textarea class="form-control" name="contenido" id="contenido" cols="30" rows="10"></textarea>
                            <?php if($errors): ?>
                                <span class="text-danger"> <?php echo e($errors->first('contenido')); ?></span>
                            <?php endif; ?>
                        </div>


                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <button class="btn btn-primary">Guardar</button>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crediapoyo\resources\views/slider/create.blade.php ENDPATH**/ ?>