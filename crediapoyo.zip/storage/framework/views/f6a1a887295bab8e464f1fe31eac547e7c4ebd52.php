<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content_header'); ?>
    <section class="content-header">
        <h1>
            Blog
            <small>Lista</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="/home"><i class="fa fa-dashboard"></i> Inicio</a></li>
            <li class="active">Blog</li>
        </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="row">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Blogs</h3>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                    <div>
                        <a href="/admin/blog/create" class="btn btn-app pull-right">
                            <i class="fa fa-plus"></i> Nuevo
                        </a>
                    </div>
                    <div class="col-md-12">
                        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <table id="blogs" class="table table-bordered table-responsive">
                        <thead>
                        <tr>
                            <th style="width: 10px">#</th>
                            <th>Titulo</th>
                            <th>Portada</th>
                            <th>Destacado</th>
                            <th>Contenido</th>
                            <th></th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                            <tr>
                                <td><?php echo e($blog->id); ?></td>
                                <td> <?php echo e($blog->title); ?></td>
                                <td class=""> <img class="img-thumbnail col-md-8" src="<?php echo e(asset('img/blog/').'/'.$blog->portada_thumb); ?>" alt="">  </td>
                                <td>
                                    <?php if($blog->highlight == 1): ?>
                                        <i class="fa  fa-star" aria-hidden="true"></i>
                                    <?php else: ?>
                                        <i class="fa  fa-star-o" aria-hidden="true"></i>
                                    <?php endif; ?>
                                </td>
                                <td class="" >
                                    <?php echo Str::limit($blog->contenido, 130); ?>

                                </td>
                                <td class="col-md-4">

                                    <?php echo e(Form::open(['route' => ['blog.destroy', $blog->id ],'class' => 'form-inline', 'method' => 'DELETE' ])); ?>

                                    <a href="<?php echo e(route('blog.edit', $blog->id)); ?>" class="btn btn-primary"> <i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>
                                    <?php if($blog->highlight == 0): ?>
                                        <a href="/admin/blog/highlight/<?php echo e($blog->id); ?>" class="btn btn-success"><i class="fa  fa-star" aria-hidden="true"></i> </a>
                                    <?php else: ?>
                                        <a href="/admin/blog/unhighlight/<?php echo e($blog->id); ?>" class="btn btn-warning"><i class="fa  fa-star" aria-hidden="true"></i> </a>
                                    <?php endif; ?>
                                    <button onclick="return confirm('¿Deseas eliminar el blog?')" class="btn btn-danger"> <i class="fa fa-trash-o" aria-hidden="true"></i> </button>
                                    <?php echo e(Form::close()); ?>

                                </td>
                            </tr>
                            </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    <div class="col-md-12 text-center">

                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/app_admin.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/adminlte/plugins/datatable/js/responsive.js')); ?>"></script>
    <script>
        $(function () {

            $('#blogs').DataTable({
                'paging'      : true,
                'lengthChange': false,
                'searching'   : true,
                'ordering'    : true,
                'info'        : true,
                'autoWidth'   : false,
                "scrollX": true
            })
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\crediapoyo\resources\views/blog/index.blade.php ENDPATH**/ ?>